*PADS-LIBRARY-PART-TYPES-V9*

MIC29302WU MIC29302WU I ANA 7 1 0 0 0
TIMESTAMP 2026.04.19.19.58.24
"Mouser Part Number" 998-MIC29302WU
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/MIC29302WU?qs=kh6iOki%2FeLGH5fS1ZBQ3pA%3D%3D
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" MIC29302WU
"Description" LDO Voltage Regulators 3.0A LDO Adj. + Shutdown
"Datasheet Link" https://www.mouser.in/datasheet/2/268/MIC2915x_30x_50x_75x_High_Current_Low_Dropout_Regu-1889172.pdf
"Geometry.Height" 5.08mm
GATE 1 6 0
MIC29302WU
1 0 U EN
2 0 U IN
3 0 U GND
4 0 U OUT
5 0 U ADJ
6 0 U TAB

*END*
*REMARK* SamacSys ECAD Model
12871005/2012225/2.50/6/0/Integrated Circuit
