*PADS-LIBRARY-PART-TYPES-V9*

PESD5V0C1BSFYL PMEG3005AESFYL I ANA 6 1 0 0 0
TIMESTAMP 2026.04.19.19.54.16
"Mouser Part Number" 771-PESD5V0C1BSFYL
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/PESD5V0C1BSFYL?qs=Pve5fMu%2FDEv%252BAQF4BlT7Aw%3D%3D
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" PESD5V0C1BSFYL
"Description" PESD5V0C1BSF - Ultra low capacitance bidirectional ESD protection diode
"Datasheet Link" https://assets.nexperia.com/documents/data-sheet/PESD5V0C1BSF.pdf
GATE 1 2 0
PESD5V0C1BSFYL
1 0 U K1
2 0 U K2

*END*
*REMARK* SamacSys ECAD Model
780273/2012225/2.50/2/2/Diode ESD (Bi-directional)
