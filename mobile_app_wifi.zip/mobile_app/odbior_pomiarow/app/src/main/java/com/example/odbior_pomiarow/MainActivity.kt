package com.example.odbior_pomiarow

import android.content.Context
import android.graphics.Color
import android.net.wifi.WifiManager
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter

import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.YAxis
import kotlinx.coroutines.*
import java.io.File
import java.io.FileWriter
import java.io.InputStream
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    companion object {
        val fullHitHistory = mutableListOf<HistoryEntry>()
    }

    private val TCP_PORT = 3333
    private val LOG_TAG = "TCP_LOGGER"
    private val LOG_FILE_PREFIX = "pomiary"
    private val UI_UPDATE_INTERVAL_MS = 50L
    private val HEARTBEAT_TIMEOUT_MS = 5000L

    private val STRUCT_SIZE = 46 // Rozmiar upakowanej struktury z ESP32

    //dotyczy wykresu
    private lateinit var liveChart: LineChart
    private var chartSampleCount = 0f
    private val MAX_VISIBLE_SAMPLES = 200

    // --- ELEMENTY UI (WIDOKI) ---
    private lateinit var lastHitTextView: TextView
    private lateinit var statusTextView: TextView
    private lateinit var connectionStatusTextView: TextView
    private lateinit var btnOpenLastShot: Button // POPRAWKA: Dodana brakująca deklaracja przycisku

    // Widok ogólnego kokpitu sesji Smart Ball
    private lateinit var tvSessionShots: TextView
    private lateinit var tvSessionEnergy: TextView
    private lateinit var tvSessionConsistency: TextView

    private lateinit var h3AccelX: TextView; private lateinit var h3AccelY: TextView; private lateinit var h3AccelZ: TextView
    private lateinit var imuAccelX: TextView; private lateinit var imuAccelY: TextView; private lateinit var imuAccelZ: TextView
    private lateinit var gyroX: TextView; private lateinit var gyroY: TextView; private lateinit var gyroZ: TextView
    private lateinit var gpsLat: TextView; private lateinit var gpsLon: TextView; private lateinit var gpsFix: TextView

    private lateinit var hitHistoryContainer: LinearLayout
    private lateinit var logSwitch: Switch

    // --- BUFORY I STANY ---
    private val eventSamples = mutableListOf<SampleData>()
    private val currentIntervalSamples = mutableListOf<SampleData>()

    private var receiveState = ReceiveState.NORMAL
    private val TOTAL_EVENT_SAMPLES = 200

    private var lastUiUpdateTime = 0L
    private var lastPacketTime = 0L

    private val scope = CoroutineScope(Dispatchers.IO)
    private var tcpServerJob: Job? = null
    private var clientSocket: Socket? = null

    private var logWriter: FileWriter? = null
    private var isLoggingEnabled = false
    private var logFile: File? = null

    private val logFileName: String
        get() = "${LOG_FILE_PREFIX}_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.csv"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initializeViews()

        startTcpServer()
        startConnectionStatusChecker()
    }

    private fun startTcpServer() {
        tcpServerJob = scope.launch {
            val espIpAddress = "192.168.4.1"

            while (isActive) {
                try {
                    Log.i(LOG_TAG, "Próba połączenia z ESP32 pod adresem $espIpAddress:$TCP_PORT...")
                    runOnUiThread {
                        statusTextView.text = "Status: Łączenie z urządzeniem..."
                    }

                    clientSocket = Socket(espIpAddress, TCP_PORT)

                    Log.i(LOG_TAG, "Połączono pomyślnie z ESP32!")
                    updateHeartbeat()

                    handleClientStream(clientSocket!!)

                } catch (e: Exception) {
                    Log.w(LOG_TAG, "Nie udało się połączyć z ESP32: ${e.message}. Ponowna próba...")
                    runOnUiThread {
                        statusTextView.text = "Status: Oczekiwanie na urządzenie..."
                    }
                    delay(3000L)
                }
            }
        }
    }

    private suspend fun handleClientStream(socket: Socket) {
        withContext(Dispatchers.IO) {
            val inputStream = socket.getInputStream()
            val buffer = ByteArray(STRUCT_SIZE)

            try {
                while (isActive && !socket.isClosed && socket.isConnected) {
                    readFully(inputStream, buffer)
                    updateHeartbeat()

                    val byteBuffer = ByteBuffer.wrap(buffer).order(ByteOrder.LITTLE_ENDIAN)
                    parseTcpStruct(byteBuffer)
                }
            } catch (e: Exception) {
                Log.w(LOG_TAG, "Błąd transmisji lub rozłączenie: ${e.message}")
            } finally {
                try { socket.close() } catch (e: Exception) {}
                runOnUiThread {
                    connectionStatusTextView.text = "Status: Rozłączono"
                    connectionStatusTextView.setBackgroundColor(Color.parseColor("#FFB3B3"))
                }
            }
        }
    }

    private fun readFully(inputStream: InputStream, buffer: ByteArray) {
        var offset = 0
        var bytesToRead = buffer.size
        while (bytesToRead > 0) {
            val bytesRead = inputStream.read(buffer, offset, bytesToRead)
            if (bytesRead == -1) throw Exception("Koniec strumienia TCP")
            offset += bytesRead
            bytesToRead -= bytesRead
        }
    }

    private fun parseTcpStruct(buffer: ByteBuffer) {
        try {
            // Upewniamy się, że czytamy od początku bufora i w odpowiednim porządku bajtów
            buffer.position(0)
            buffer.order(ByteOrder.LITTLE_ENDIAN)

            // Odczyt typu pakietu (1 bajt)
            val packetType = buffer.get().toInt()

            // Odczyt akcelerometru wysokich przeciążeń H3 (3x float)
            val h3_ax = buffer.getFloat()
            val h3_ay = buffer.getFloat()
            val h3_az = buffer.getFloat()

            // Odczyt głównego akcelerometru IMU (3x float)
            val imu_ax = buffer.getFloat()
            val imu_ay = buffer.getFloat()
            val imu_az = buffer.getFloat()

            // Odczyt żyroskopu IMU (3x float)
            val imu_gx = buffer.getFloat()
            val imu_gy = buffer.getFloat()
            val imu_gz = buffer.getFloat()

            // Odczyt współrzędnych GPS oraz statusu FIX
            val lat = buffer.getFloat()
            val lon = buffer.getFloat()
            val gpsFix = buffer.get() != 0.toByte()

            val ts = System.currentTimeMillis()

            // Przeliczenie wartości IMU na mili-G (mnożenie * 1000f) zgodnie z Twoją logiką
            val imuAxMg = imu_ax * 1000f
            val imuAyMg = imu_ay * 1000f
            val imuAzMg = imu_az * 1000f

            val currentSample = SampleData(
                imuAxMg, imuAyMg, imuAzMg,
                imu_gx, imu_gy, imu_gz, ts
            )

            // DODANO: Aktualizacja wykresu w czasie rzeczywistym przy każdej odebranej próbce.
            // Przekazujemy wartości H3 oraz IMU już przeliczone na jednostki mg (mili-G),
            // funkcja addSampleToChart podzieli je przez 1000f, aby na wykresie ładnie wyświetlić pełne "G".
            addSampleToChart(
                h3_ax, h3_ay, h3_az,
                imuAxMg, imuAyMg, imuAzMg,
                imu_gx, imu_gy, imu_gz
            )

            // Zapis do pliku CSV, jeśli logowanie jest aktywne
            if (isLoggingEnabled) {
                writeSampleToCsv(
                    h3_ax, h3_ay, h3_az,
                    imuAxMg, imuAyMg, imuAzMg,
                    imu_gx, imu_gy, imu_gz,
                    lat, lon, gpsFix
                )
            }

            // Obsługa logiki w zależności od typu pakietu
            if (packetType == 0) {
                receiveState = ReceiveState.NORMAL
                displaySensorData(
                    h3_ax, h3_ay, h3_az,
                    imuAxMg, imuAyMg, imuAzMg,
                    imu_gx, imu_gy, imu_gz,
                    lat, lon, gpsFix
                )
                analyzeFlight(currentSample)
            }
            else if (packetType == 1) {
                if (receiveState == ReceiveState.NORMAL) {
                    receiveState = ReceiveState.EVENT_RECEIVING
                    eventSamples.clear()
                    runOnUiThread {
                        statusTextView.text = "!!! WYKRYTO ZDERZENIE: ODBIERANIE PACZKI Z ESP32 !!!"
                        statusTextView.setTextColor(Color.RED)
                    }
                }

                eventSamples.add(currentSample.copy(isLive = false))

                if (eventSamples.size >= TOTAL_EVENT_SAMPLES) {
                    finalizeEventProcessing()
                }
            }
        } catch (e: Exception) {
            Log.e(LOG_TAG, "Błąd podczas parsowania struktury TCP: ${e.message}")
            e.printStackTrace()
        }
    }

    private fun finalizeEventProcessing() {
        val samplesToDraw = ArrayList(eventSamples)
        receiveState = ReceiveState.NORMAL
        currentIntervalSamples.clear()

        if (samplesToDraw.isEmpty()) return

        val duration = samplesToDraw.size * 10L
        val peakForce = samplesToDraw.maxOf {
            sqrt((it.ax * it.ax + it.ay * it.ay + it.az * it.az).toDouble()).toFloat()
        }

        runOnUiThread {
            addHitToHistory(Date(), duration, peakForce, samplesToDraw)

            // AUTOMATYCZNE OTWARCIE ANALIZATORA UDERZENIA NA ŻYWO
            ShotDetailsActivity.selectedSamples = samplesToDraw
            ShotDetailsActivity.peakValue = peakForce
            ShotDetailsActivity.entryType = EntryType.HIT

            val intent = Intent(this, ShotDetailsActivity::class.java)
            startActivity(intent)

            statusTextView.text = "Wykryto kopnięcie! Otwarto analizator uderzenia."
            statusTextView.setTextColor(Color.BLACK)
        }
        eventSamples.clear()
    }

    private fun setupLiveChart() {
        // 1. Podstawowa konfiguracja wyglądu wykresu
        liveChart.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            isScaleXEnabled = true
            isScaleYEnabled = false // Blokujemy skalowanie pionowe dla czytelności
            setPinchZoom(false)
            setBackgroundColor(Color.WHITE)
        }

        // 2. Przygotowanie pustych serii danych
        val setImuAccel = LineDataSet(mutableListOf(), "Akcelerometr IMU [G]").apply {
            color = Color.RED
            setDrawCircles(false)
            lineWidth = 2f
            setDrawValues(false)
            axisDependency = YAxis.AxisDependency.LEFT
        }

        val setH3Accel = LineDataSet(mutableListOf(), "Akcelerometr H3 [G]").apply {
            color = Color.BLACK
            setDrawCircles(false)
            lineWidth = 2f
            setDrawValues(false)
            axisDependency = YAxis.AxisDependency.LEFT
        }

        val setGyro = LineDataSet(mutableListOf(), "Żyroskop [dps]").apply {
            color = Color.YELLOW
            setDrawCircles(false)
            lineWidth = 2f
            setDrawValues(false)
            axisDependency = YAxis.AxisDependency.RIGHT // Przypisanie do prawej osi Y
        }

        // 3. Przypisanie serii danych do wykresu (To musi być przed konfiguracją granic osi!)
        val lineData = LineData(setImuAccel, setH3Accel, setGyro)
        liveChart.data = lineData

        // 4. Stylizacja osi X (Czas / Próbki)
        liveChart.xAxis.apply {
            textColor = Color.BLACK
            setDrawGridLines(true)
            isEnabled = true
        }

        // 5. Lewa oś Y (Przeznaczona dla obu Akcelerometrów - jednostka: G)
        // TUTAJ WYŁĄCZAMY DYNAMICZNĄ SKALĘ I BLOKUJEMY JĄ NA STAŁE OD 0 DO 5G
        liveChart.axisLeft.apply {
            textColor = Color.RED
            setDrawGridLines(true)

            axisMinimum = 0f            // Minimalna wartość na osi to 0G
            axisMaximum = 5f            // Maksymalna wartość na osi to sztywne 5G

            isGranularityEnabled = true
            granularity = 1f            // Linie pomocnicze siatki dokładnie co 1G
        }

        // 6. Prawa oś Y (Przeznaczona dla Żyroskopu - jednostka: stopnie/s)
        liveChart.axisRight.apply {
            textColor = Color.BLUE
            setDrawGridLines(false)     // Wyłączamy linie siatki, by nie nakładały się na lewą oś
            axisMinimum = 0f            // Rotacja nie będzie ujemna
        }
    }

    // MODYFIKACJA METODY: Dodawanie punktu w czasie rzeczywistym
    private fun addSampleToChart(h3x: Float, h3y: Float, h3z: Float, ax: Float, ay: Float, az: Float, gx: Float, gy: Float, gz: Float) {
        // PRZENIESIENIE CAŁOŚCI LOGIKI DO RUNONUITHREAD ZABEZPIECZA PRZED INDEXOUTOFBOUNDSEXCEPTION
        runOnUiThread {
            val data = liveChart.data ?: return@runOnUiThread

            val setImu = data.getDataSetByIndex(0)
            val setH3 = data.getDataSetByIndex(1)
            val setGyro = data.getDataSetByIndex(2)

            // Obliczanie długości wektorów wypadkowych (Magnitude)
            val imuMag = sqrt((ax * ax + ay * ay + az * az).toDouble()).toFloat() / 1000f
            val h3Mag = sqrt((h3x * h3x + h3y * h3y + h3z * h3z).toDouble()).toFloat() / 1000f
            val gyroMag = sqrt((gx * gx + gy * gy + gz * gz).toDouble()).toFloat()

            // Bezpieczne dodawanie nowych punktów na wątku głównym UI
            data.addEntry(Entry(chartSampleCount, imuMag), 0)
            data.addEntry(Entry(chartSampleCount, h3Mag), 1)
            data.addEntry(Entry(chartSampleCount, gyroMag), 2)

            chartSampleCount++

            // Bezpieczne usuwanie starych próbek — brak konfliktu z LineChartRenderer
            if (setImu.entryCount > MAX_VISIBLE_SAMPLES) setImu.removeEntry(0)
            if (setH3.entryCount > MAX_VISIBLE_SAMPLES) setH3.removeEntry(0)
            if (setGyro.entryCount > MAX_VISIBLE_SAMPLES) setGyro.removeEntry(0)

            // Powiadomienie wykresu i natychmiastowe przerysowanie
            data.notifyDataChanged()
            liveChart.notifyDataSetChanged()

            // Ograniczenie widoku osi X do najświeższych próbek
            liveChart.xAxis.axisMinimum = (chartSampleCount - MAX_VISIBLE_SAMPLES).coerceAtLeast(0f)
            liveChart.xAxis.axisMaximum = chartSampleCount

            liveChart.invalidate()
        }
    }

    // POPRAWKA: Przywrócenie brakującej metody analizy lotu, która zbiera paczki currentIntervalSamples
    private fun analyzeFlight(sample: SampleData) {
        currentIntervalSamples.add(sample)
        if (currentIntervalSamples.size > 300) {
            currentIntervalSamples.removeAt(0)
        }
        if (currentIntervalSamples.size % 100 == 0) {
            processFlightData()
        }
    }

    private fun displaySensorData(
        h3x: Float, h3y: Float, h3z: Float,
        ax: Float, ay: Float, az: Float,
        gx: Float, gy: Float, gz: Float,
        lat: Float, lon: Float, fix: Boolean
    ) {
        val now = System.currentTimeMillis()
        if (now - lastUiUpdateTime < UI_UPDATE_INTERVAL_MS) return
        lastUiUpdateTime = now

        runOnUiThread {
            h3AccelX.text = String.format("X: %.2f G", h3x)
            h3AccelY.text = String.format("Y: %.2f G", h3y)
            h3AccelZ.text = String.format("Z: %.2f G", h3z)

            imuAccelX.text = String.format("X: %.1f mg", ax)
            imuAccelY.text = String.format("Y: %.1f mg", ay)
            imuAccelZ.text = String.format("Z: %.1f mg", az)

            gyroX.text = String.format("X: %.1f dps", gx)
            gyroY.text = String.format("Y: %.1f dps", gy)
            gyroZ.text = String.format("Z: %.1f dps", gz)

            gpsLat.text = String.format("Szer: %.5f°", lat)
            gpsLon.text = String.format("Dług: %.5f°", lon)
            if (fix) {
                gpsFix.text = "FIX: TAK"
                gpsFix.setTextColor(Color.parseColor("#006400"))
            } else {
                gpsFix.text = "FIX: BRAK"
                gpsFix.setTextColor(Color.RED)
            }

            // --- GLOBALNY KOKPIT TRENINGOWY Smart Ball ---
            val totalHits = fullHitHistory.count { it.type == EntryType.HIT }
            val totalEnergyJ = MetricsCalculator.calculateTotalEnergyExpenditureJ(fullHitHistory)
            val consistencyPct = MetricsCalculator.calculateConsistencyScore(fullHitHistory)

            tvSessionShots.text = "Suma uderzeń: $totalHits"
            tvSessionEnergy.text = String.format("Energia sesji: %.1f J", totalEnergyJ)
            tvSessionConsistency.text = "Powtarzalność: $consistencyPct%"

            statusTextView.text = "Status: Odbieram dane..."
            statusTextView.setTextColor(Color.BLACK)
        }
    }

    private fun addHitToHistory(hitDate: Date, durationMs: Long, peakForce: Float, currentSamples: List<SampleData>) {
        val newHit = HistoryEntry(EntryType.HIT, hitDate, durationMs, currentSamples, peakValue = peakForce)
        fullHitHistory.add(0, newHit)

        runOnUiThread {
            val forceInG = peakForce / 1000f
            lastHitTextView.text = String.format("Ostatnie: %.2f G (%d ms)", forceInG, durationMs)
            lastHitTextView.setBackgroundColor(Color.parseColor("#FFD700"))

            val quickSummary = TextView(this).apply {
                text = String.format("💥 %.2f G | %d ms", forceInG, durationMs)
                textSize = 14f
            }
            hitHistoryContainer.addView(quickSummary, 0)
        }
    }

    private fun updateHeartbeat() {
        lastPacketTime = System.currentTimeMillis()
        runOnUiThread {
            connectionStatusTextView.text = "Status: Połączono"
            connectionStatusTextView.setTextColor(Color.BLACK)
            connectionStatusTextView.setBackgroundColor(Color.parseColor("#B3FFB3"))
        }
    }

    private fun startConnectionStatusChecker() {
        scope.launch(Dispatchers.Main) {
            while (isActive) {
                delay(1000L)
                if (System.currentTimeMillis() - lastPacketTime > HEARTBEAT_TIMEOUT_MS) {
                    connectionStatusTextView.text = "Status: Rozłączono"
                    connectionStatusTextView.setTextColor(Color.RED)
                    connectionStatusTextView.setBackgroundColor(Color.parseColor("#FFB3B3"))
                }
            }
        }
    }

    private fun processFlightData() {
        if (currentIntervalSamples.size < 10) return
        val flightSegment = ArrayList(currentIntervalSamples)

        val maxRotationDps = flightSegment.maxOf {
            sqrt((it.gx * it.gx + it.gy * it.gy + it.gz * it.gz).toDouble()).toFloat()
        }

        runOnUiThread {
            // Zapisujemy zakończony segment lotu do historii jako EntryType.FLIGHT
            val flightDuration = flightSegment.size * 10L
            val newFlightEntry = HistoryEntry(EntryType.FLIGHT, Date(), flightDuration, flightSegment, maxRotationDps)
            fullHitHistory.add(0, newFlightEntry)

            // AUTOMATYCZNE OTWARCIE ANALIZATORA DLA FAZY LOTU PIŁKI
            /*
            ShotDetailsActivity.selectedSamples = flightSegment
            ShotDetailsActivity.peakValue = maxRotationDps
            ShotDetailsActivity.entryType = EntryType.FLIGHT

            val intent = Intent(this, ShotDetailsActivity::class.java)
            startActivity(intent)
*/
            lastHitTextView.text = String.format("Lot zakończony. Maks. rotacja: %.0f RPM", maxRotationDps / 6f)
            lastHitTextView.setBackgroundColor(Color.CYAN)
        }
    }

    private fun initializeViews() {
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<Button>(R.id.btnShowHistory).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<Button>(R.id.btnShowLocation).setOnClickListener {
            startActivity(Intent(this, LocationActivity::class.java))
        }

        liveChart = findViewById(R.id.mainLiveChart)
        setupLiveChart()

        lastHitTextView = findViewById(R.id.lastHitTextView)
        statusTextView = findViewById(R.id.statusTextView)
        connectionStatusTextView = findViewById(R.id.connectionStatusTextView)

        // Obsługa przycisku otwierania analizatora ostatniego zarejestrowanego zdarzenia
        btnOpenLastShot = findViewById(R.id.btnOpenLastShot)
        btnOpenLastShot.setOnClickListener {
            if (fullHitHistory.isNotEmpty()) {
                val lastEntry = fullHitHistory[0] // Pobierz najnowsze zdarzenie z listy
                ShotDetailsActivity.selectedSamples = lastEntry.samples
                ShotDetailsActivity.peakValue = lastEntry.peakValue
                ShotDetailsActivity.entryType = lastEntry.type

                val intent = Intent(this, ShotDetailsActivity::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Brak zarejestrowanych zdarzeń w obecnej sesji!", Toast.LENGTH_SHORT).show()
            }
        }

        // POPRAWKA: Usunięto zdublowane powiązanie tvSessionShots i podpięto komplet widoków sesji
        tvSessionShots = findViewById(R.id.tvSessionShots)
        tvSessionEnergy = findViewById(R.id.tvSessionEnergy)
        tvSessionConsistency = findViewById(R.id.tvSessionConsistency)

        h3AccelX = findViewById(R.id.h3AccelX)
        h3AccelY = findViewById(R.id.h3AccelY)
        h3AccelZ = findViewById(R.id.h3AccelZ)

        imuAccelX = findViewById(R.id.imuAccelX)
        imuAccelY = findViewById(R.id.imuAccelY)
        imuAccelZ = findViewById(R.id.imuAccelZ)

        gyroX = findViewById(R.id.gyroX)
        gyroY = findViewById(R.id.gyroY)
        gyroZ = findViewById(R.id.gyroZ)

        gpsLat = findViewById(R.id.gpsLat)
        gpsLon = findViewById(R.id.gpsLon)
        gpsFix = findViewById(R.id.gpsFix)

        hitHistoryContainer = findViewById(R.id.hitHistoryContainer)
        logSwitch = findViewById(R.id.logSwitch)

        logSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) initLogFile()
            else {
                isLoggingEnabled = false
                logWriter?.close()
                logWriter = null
                Log.i(LOG_TAG, "Logowanie CSV wyłączone.")
            }
        }
    }

    private fun initLogFile() {
        val appDirectory = getExternalFilesDir(null) ?: return
        logFile = File(appDirectory, logFileName)
        try {
            logWriter = FileWriter(logFile, true)
            logWriter?.write("Timestamp,H3_AX,H3_AY,H3_AZ,IMU_AX,IMU_AY,IMU_AZ,IMU_GX,IMU_GY,IMU_GZ,Lat,Lon,Fix\n")
            isLoggingEnabled = true
            Toast.makeText(this, "Zapis do: ${logFile?.name}", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            isLoggingEnabled = false
            logSwitch.isChecked = false
        }
    }

    private fun writeSampleToCsv(h3x: Float, h3y: Float, h3z: Float, ax: Float, ay: Float, az: Float, gx: Float, gy: Float, gz: Float, lat: Float, lon: Float, fix: Boolean) {
        scope.launch(Dispatchers.IO) {
            try {
                logWriter?.write("${System.currentTimeMillis()},$h3x,$h3y,$h3z,$ax,$ay,$az,$gx,$gy,$gz,$lat,$lon,${if(fix) 1 else 0}\n")
                logWriter?.flush()
            } catch (e: Exception) {
                Log.e(LOG_TAG, "Błąd zapisywania wiersza CSV: ${e.message}")
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            clientSocket?.close()
            logWriter?.close()
        } catch (e: Exception) {
            Log.e(LOG_TAG, "Błąd zamykania zasobów: ${e.message}")
        }
        tcpServerJob?.cancel()
    }
}