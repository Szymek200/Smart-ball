*PADS-LIBRARY-PART-TYPES-V9*

DS1013-40SSIB1-B-0 DS101340SSIB1B0 I CON 7 1 0 0 0
TIMESTAMP 2026.04.16.10.27.51
"TME Electronic Components Part Number" 
"TME Electronic Components Price/Stock" 
"Manufacturer_Name" Connfly
"Manufacturer_Part_Number" DS1013-40SSIB1-B-0
"Description" BOX HEADER 40PIN(2x20) 2.54mm THT V/T MALE BLACK
"Datasheet Link" https://www.tme.eu/Document/c6e6da985bd9c519d97c4924b5c8a047/DS1013.pdf
"Geometry.Height" 9.48mm
GATE 1 40 0
DS1013-40SSIB1-B-0
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10
11 0 U 11
12 0 U 12
13 0 U 13
14 0 U 14
15 0 U 15
16 0 U 16
17 0 U 17
18 0 U 18
19 0 U 19
20 0 U 20
21 0 U 21
22 0 U 22
23 0 U 23
24 0 U 24
25 0 U 25
26 0 U 26
27 0 U 27
28 0 U 28
29 0 U 29
30 0 U 30
31 0 U 31
32 0 U 32
33 0 U 33
34 0 U 34
35 0 U 35
36 0 U 36
37 0 U 37
38 0 U 38
39 0 U 39
40 0 U 40

*END*
*REMARK* SamacSys ECAD Model
19591747/2012225/2.50/40/3/Connector
