*PADS-LIBRARY-PART-TYPES-V9*

TPS6213013AQRGTTQ1 QFN50P300X300X100-17N-D I ANA 7 1 0 0 0
TIMESTAMP 2026.04.19.20.28.19
"Mouser Part Number" 595-S6213013AQRGTTQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS6213013AQRGTTQ1?qs=0C8XhJW8e4pvgQLdWHTrzg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS6213013AQRGTTQ1
"Description" 3V - 17V 3A AUTOMOTIVE Step-Down Converter In 3X3 QFN Package
"Datasheet Link" http://www.ti.com/lit/gpn/TPS6213013A-Q1
"Geometry.Height" 1mm
GATE 1 17 0
TPS6213013AQRGTTQ1
1 0 U SW_1
2 0 U SW_2
3 0 U SW_3
4 0 U PG
5 0 U FB
6 0 U AGND
7 0 U FSW
8 0 U DEF
12 0 U PVIN_2
11 0 U PVIN_1
10 0 U AVIN
9 0 U SS/TR
17 0 U EP
16 0 U PGND_2
15 0 U PGND_1
14 0 U VOS
13 0 U EN

*END*
*REMARK* SamacSys ECAD Model
877516/2012225/2.50/17/3/Integrated Circuit
