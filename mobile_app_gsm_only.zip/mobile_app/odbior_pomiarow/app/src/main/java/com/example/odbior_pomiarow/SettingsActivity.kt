package com.example.odbior_pomiarow

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Socket

class SettingsActivity : AppCompatActivity() {

    private val ESP_IP = "192.168.4.1"
    private val CONFIG_PORT = 3334 // Dedykowany port konfiguracji z ESP32

    private lateinit var etWakeupThs: EditText
    private lateinit var etHitThs: EditText
    private lateinit var etIdleTime: EditText
    private lateinit var etSleepThs: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // Powiązanie widoków
        etWakeupThs = findViewById(R.id.etWakeupThreshold)
        etHitThs = findViewById(R.id.etHitThreshold)
        etIdleTime = findViewById(R.id.etIdleTime)
        etSleepThs = findViewById(R.id.etSleepThreshold)

        val btnSetWakeup = findViewById<Button>(R.id.btnSetWakeup)
        val btnSetHit = findViewById<Button>(R.id.btnSetHit)
        val btnSetIdle = findViewById<Button>(R.id.btnSetIdle)
        val btnSetSleepThs = findViewById<Button>(R.id.btnSetSleepThs)
        val btnBack = findViewById<Button>(R.id.btnBackFromSettings)

        // AKTUALIZACJA: Pobierz rzeczywiste parametry z ESP32 od razu po otwarciu okna
        fetchCurrentSettings()

        // Obsługa wysyłania zmian parametrów
        btnSetWakeup.setOnClickListener {
            val valueStr = etWakeupThs.text.toString().replace(",", ".")
            if (valueStr.toFloatOrNull() != null) sendCommand("CMD:WAKE_THS:$valueStr")
        }

        btnSetHit.setOnClickListener {
            val valueStr = etHitThs.text.toString().replace(",", ".")
            if (valueStr.toFloatOrNull() != null) sendCommand("CMD:HIT_THS:$valueStr")
        }

        btnSetIdle.setOnClickListener {
            val valueStr = etIdleTime.text.toString()
            if (valueStr.toIntOrNull() != null) sendCommand("CMD:IDLE_TIME:$valueStr")
        }

        btnSetSleepThs.setOnClickListener {
            val valueStr = etSleepThs.text.toString().replace(",", ".")
            if (valueStr.toFloatOrNull() != null) sendCommand("CMD:SLEEP_THS:$valueStr")
        }

        btnBack.setOnClickListener { finish() }
    }

    // Pobieranie aktualnej konfiguracji z ESP32 (Port 3334)
    private fun fetchCurrentSettings() {
        CoroutineScope(Dispatchers.IO).launch {
            var socket: Socket? = null
            try {
                socket = Socket(ESP_IP, CONFIG_PORT)
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))

                // ESP32 po akceptacji połączenia natychmiast wysyła linię tekstu kończącą się '\n'
                val response = reader.readLine()

                if (response != null && response.startsWith("CFG:")) {
                    // Przykładowa ramka z ESP32: "CFG:1.50:0.050:120:4.5"
                    val tokens = response.split(":")
                    if (tokens.size >= 5) {
                        withContext(Dispatchers.Main) {
                            etWakeupThs.setText(tokens[1])
                            etSleepThs.setText(tokens[2])
                            etIdleTime.setText(tokens[3])
                            etHitThs.setText(tokens[4])
                            Toast.makeText(applicationContext, "Pobrano aktualną konfigurację z ESP32", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    Toast.makeText(applicationContext, "Nie udało się pobrać ustawień: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } finally {
                try { socket?.close() } catch (e: Exception) {}
            }
        }
    }

    // Wysyłanie nowej konfiguracji do ESP32 (Port 3334)
    private fun sendCommand(command: String) {
        CoroutineScope(Dispatchers.IO).launch {
            var socket: Socket? = null
            try {
                socket = Socket(ESP_IP, CONFIG_PORT)
                val outputStream = socket.getOutputStream()
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))

                // ESP32 najpierw automatycznie wysyła linię CFG po połączeniu – musimy ją odebrać/zrzucić,
                // aby oczyścić strumień wejściowy przed wysłaniem komendy
                reader.readLine()

                // Wysyłamy nową komendę tekstową zakończoną znakiem nowej linii
                val commandBytes = (command + "\n").toByteArray(Charsets.UTF_8)
                outputStream.write(commandBytes)
                outputStream.flush()

                // Oczekiwanie na odpowiedź "STATUS:OK" z mikrokontrolera
                val status = reader.readLine()

                withContext(Dispatchers.Main) {
                    if (status == "STATUS:OK") {
                        Toast.makeText(applicationContext, "Zapisano w urządzeniu!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(applicationContext, "Wysłano: $command", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    Toast.makeText(applicationContext, "Błąd komunikacji TCP: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } finally {
                try { socket?.close() } catch (e: Exception) {}
            }
        }
    }
}