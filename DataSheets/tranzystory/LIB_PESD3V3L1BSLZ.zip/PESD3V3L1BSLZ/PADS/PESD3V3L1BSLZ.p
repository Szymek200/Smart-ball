*PADS-LIBRARY-PART-TYPES-V9*

PESD3V3L1BSLZ PESD3V3L1BSLZ I ANA 7 1 0 0 0
TIMESTAMP 2026.04.08.07.52.20
"Mouser Part Number" 771-PESD3V3L1BSLZ
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/PESD3V3L1BSLZ?qs=Li%252BoUPsLEnsrB%2FnSgNrAWw%3D%3D
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" PESD3V3L1BSLZ
"Description" 11.3V Clamp 7.5A (8/20s) Ipp Tvs Diode Surface Mount DFN1006-2
"Datasheet Link" https://assets.nexperia.com/documents/data-sheet/PESD3V3L1BSL.pdf
"Geometry.Height" 0.45mm
GATE 1 2 0
PESD3V3L1BSLZ
1 0 U K1
2 0 U K2

*END*
*REMARK* SamacSys ECAD Model
16415732/2012225/2.50/2/2/Diode ESD (Bi-directional)
