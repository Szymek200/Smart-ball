*PADS-LIBRARY-PART-TYPES-V9*

SS14MDP2 SS14MDP2 I SWI 7 1 0 0 0
TIMESTAMP 2026.04.16.11.10.11
"Mouser Part Number" 633-SS14MDP2
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/NKK-Switches/SS14MDP2?qs=tJRqkAIQG4xAbyvlpPIZ4A%3D%3D
"Manufacturer_Name" NKK Switches
"Manufacturer_Part_Number" SS14MDP2
"Description" PCB Slide Switch SP3T On-On-On 100 mA Top
"Datasheet Link" http://www.nkkswitches.com/pdf/SSnonilluminated.pdf
"Geometry.Height" 6.5mm
GATE 1 4 0
SS14MDP2
1 0 U NO_1
2 0 U NO_2
3 0 U COM
4 0 U NC

*END*
*REMARK* SamacSys ECAD Model
285291/2012225/2.50/4/4/Switch
